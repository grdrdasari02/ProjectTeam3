package com.proj.Main;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.proj.model.Employee;
import com.proj.model.LeaveReq;
import com.proj.service.EmployeeService;
import com.proj.service.LeaveRequestService;

/**
 * The main class that contains all the console interaction statements and calls service class
 * methods for database operations.
 * @author Giridhar D
 */
public class Main {
	
	
	private static final String RESET = "\033[0m";
    private static final String GREEN = "\033[0;32m";
    private static final String YELLOW = "\033[0;33m";
    private static final String BLUE = "\033[0;34m";
    private static final String PURPLE = "\033[0;35m";
    private static final String RED = "\033[0;31m";
    private static final String CYAN = "\033[0;36m";
    
    private static LeaveRequestService lrs = new LeaveRequestService(); 
    private static EmployeeService es = new EmployeeService();
    private static Scanner sc = new Scanner(System.in);

	/**
	 *  The main method provides the primary menu in the console which provides the option of 
	 *	either handling employee table operations or handling leave request table operations.
	 */
	public static void main(String[] args) throws ParseException {



		while (true) {
			System.out.println(PURPLE + "\n*************************************************************************************" + RESET);
			System.out.println(PURPLE + "\t\t\t\tWelcome to the Leave Management System" + RESET);
			System.out.println(PURPLE + "*************************************************************************************" + RESET);
			System.out.println(BLUE + "Please select an option from the menu below:" + RESET);
			System.out.println(BLUE + "1. Employee Management (For Admin)" + RESET);
			System.out.println(CYAN + "   		- Add and view employee records." + RESET);
			System.out.println(BLUE + "2. Leave Request Management (For Employee)" + RESET);
			System.out.println(CYAN + "   		- Apply, approve, and view leave requests." + RESET);
			System.out.println(BLUE + "3. Exit" + RESET);
			System.out.print(BLUE + "Enter your choice (1-3): " + RESET);

			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				handleEmployeeManagement();
				break;
			case 2:
				handleLeaveRequestManagement();
				break;
			case 3:
				System.out.println(GREEN + "\nThank you for using the Leave Management System. Have a great day!" + RESET);
				return;
			default:
				System.out.println(RED + "\nInvalid selection. Please choose a valid option." + RESET);
			}
		}
	}

	/**
	 * 	This method is called in the main() method when user(now essentially of an 
	 * 	administrator level) selects employee management option in the primary menu.
	 * 	This menu provides the options of either viewing all the employees or adding a new employee.
	 */
	private static void handleEmployeeManagement() {

		while (true) {
			System.out.println(PURPLE + "\n*******************************************************************************" + RESET);
			System.out.println(PURPLE + "\t\t\t\tEmployee Management Portal" + RESET);
			System.out.println(PURPLE + "*******************************************************************************" + RESET);
			System.out.println(BLUE + "Please choose an option:" + RESET);
			System.out.println(BLUE + "1. View All Employees" + RESET);
			System.out.println(CYAN + "   		- Displays a list of all registered employees." + RESET);
			System.out.println(BLUE + "2. Add a New Employee" + RESET);
			System.out.println(CYAN + "   		- Add details of a new employee to the system." + RESET);
			System.out.println(BLUE + "3. Return to Main Menu" + RESET);
			System.out.print(BLUE + "Enter your choice (1-3): " + RESET);

			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				viewAllEmployees();
				break;
			case 2:
				addNewEmployee();
				break;
			case 3:
				System.out.println(GREEN + "\nReturning to the main menu..." + RESET);
				return;
			default:
				System.out.println(RED + "\nInvalid selection. Please choose a valid option." + RESET);
			}
		}
	}

	/**
	 * This method is called in handleEmployeeManagement() method when the admin/user selects
	 * view all employees option from the Employee Management menu. This method further calls
	 * getAllEmployees() method from EmployeeService class which returns a list of all the employees.
	 */
	private static void viewAllEmployees() {

		List<Employee> le = es.getAllEmployees();

		System.out.println(GREEN + "\nHere's the list of all the registered employees :-\n" + RESET);

		System.out.println(GREEN + "+-------+----------------------+-----------------+------------+------------+" + RESET);
	    System.out.println(GREEN + "| ID    | Name                 | Department      | Is Manager | Manager ID |" + RESET);
	    System.out.println(GREEN + "+-------+----------------------+-----------------+------------+------------+" + RESET);

	    for (Employee employee : le) {
	        System.out.println(GREEN + employee.toString() + RESET);
	    }

	    System.out.println(GREEN + "+-------+----------------------+-----------------+------------+------------+" + RESET);
	}

	/**
	 * 	This method is called in handleEmployeeManagement() method when the admin/user selects
	 * 	add a new employee option from the Employee Management menu. This method gets necessary
	 * 	input from the user and creates an Employee object. And then it further calls
	 * 	addEmployees() method from EmployeeService class with the created object as parameter.
	 */
	private static void addNewEmployee() {


		System.out.println(PURPLE + "\n--- Add New Employee ---" + RESET);

		System.out.print(BLUE + "Enter the Employee ID (Numeric): " + RESET);
		int id = sc.nextInt();
		sc.nextLine();

		System.out.print(BLUE + "Enter the Employee's Full Name: " + RESET);
		String name = sc.nextLine();

		System.out.print(BLUE + "Enter the Department Name (e.g., HR, IT, Finance): " + RESET);
		String department = sc.nextLine();

		System.out.print(BLUE + "Is the Employee a Manager? (TRUE/FALSE): \n" + RESET);
		boolean isManager = sc.nextBoolean();

		System.out.print(BLUE + "Enter Manager ID (Enter 0 if not applicable): " + RESET);
		int managerId = sc.nextInt();
		System.out.println();


		es.addEmployees(new Employee(id, name, department, isManager, managerId));
		
	}
	
	
	
	/**
	 * This method is called in the main() method when user selects employee management option
	 * in the primary menu. This menu provides the options of applying leaves, approving leaves(only
	 * for managers) or viewing leaves.
	 * @throws ParseException  
	 */

	
	private static void handleLeaveRequestManagement() throws ParseException {


		while (true) {
			System.out.println(PURPLE + "\n***********************************************************************************" + RESET);
			System.out.println(PURPLE + "\t\t\t\tLeave Request Management Portal" + RESET);
			System.out.println(PURPLE + "***********************************************************************************" + RESET);
			System.out.println(BLUE + "Manage leave requests for employees:" + RESET);
			System.out.println(BLUE + "1. Apply for Leave" + RESET);
			System.out.println(CYAN + "   		- Submit a leave request for approval." + RESET);
			System.out.println(BLUE + "2. View All Leave Requests" + RESET);
			System.out.println(CYAN + "   		- Display all submitted leave requests with their current status." + RESET);
			System.out.println(BLUE + "3. View Your Leave Requests" + RESET);
			System.out.println(CYAN + "   		- Display all submitted leave requests raised by you with their current status." + RESET);
			System.out.println(PURPLE + "--- Managers Only Operations ---" + RESET);
			System.out.println(BLUE + "4. View Your Leave Requests for Approval" + RESET);
			System.out.println(CYAN + "   		- Display all submitted leave requests raised by employees who report to you" + RESET);
			System.out.println(BLUE + "5. Approve Leave" + RESET);
			System.out.println(CYAN + "   		- Approve or reject leave requests submitted by employees." + RESET);
			System.out.println(BLUE + "6. Return to Main Menu" + RESET);
			System.out.print(BLUE + "Enter your choice (1-6): " + RESET);

			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				applyForLeave();
				break;
			case 2:
				viewAllLeaveRequests();
				break;
			case 3:
				viewYourLeaveRequests();
				break;
			case 4:
				viewYourLeaveRequestsForApproval();
				break;
			case 5:
				approveLeave();
				break;
			case 6:
				System.out.println(GREEN + "\nReturning to the main menu..." + RESET);
				return;
			default:
				System.out.println(RED + "\nInvalid selection. Please choose a valid option." + RESET);
			}
		}
	}

	/**
	 * This method gets called in the handeLeaveRequestManagement() method when the user selects
	 * apply for leave option in the leave request management menu. This method gets necessary
	 * input from the user and creates a LeaveReq object. And then it further calls
	 * addLeveReq() method from LeaveRequestService class with the created object as parameter.
	 */
	private static void applyForLeave() throws ParseException {

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

		System.out.println(PURPLE + "\n--- Apply for Leave ---" + RESET);

		int id = 0;

		System.out.print(BLUE + "Enter your Employee ID: " + RESET);
		int empId = sc.nextInt();
		sc.nextLine();

		System.out.print(BLUE + "Enter the start date for leave (in YYYY-MM-DD format): " + RESET);
		Date sdate = dateFormat.parse(sc.nextLine());

		System.out.print(BLUE + "Enter the end date for leave (in YYYY-MM-DD format): " + RESET);
		Date edate = dateFormat.parse(sc.nextLine());

		System.out.print(BLUE + "Enter the type of leave (e.g. Sick Leave, Casual Leave...): " + RESET);
		String type = sc.nextLine();

		String status = "PENDING";

		lrs.addLeaveReq(new LeaveReq(id, empId, sdate, edate, type, status));
	}

	/**
	 * This method gets called in the handeLeaveRequestManagement() method when the user(now 
	 * essentially a manager) selects approve leave option in the leave request management menu.
	 * This method gets necessary input from the user and calls updateLeaveStatus() method from 
	 * LeaveRequestService class with the input as parameters.
	 * 
	 */
	private static void approveLeave() {
	 


		System.out.println(PURPLE + "\n--- Approve Leave Request(s) ---" + RESET);

		System.out.print(BLUE + "Enter your Employee ID: " + RESET);
		int manId = sc.nextInt();

		System.out.print(BLUE + "Enter the leave ID you want to approve: " + RESET);
		int lvId = sc.nextInt();

		System.out.println(BLUE + "Is the leave APPROVED or REJECTED: " + RESET);
		String status = sc.next();

		lrs.updateLeaveStatus(manId, lvId, status);

	}

	/**
	 * This method gets called in the handeLeaveRequestManagement() method when the user
	 * selects view all leave requests option in the leave request management menu. This method 
	 * further calls getAllLeaveRequests() from LeaveRequestService class which returns a list.
	 */
	private static void viewAllLeaveRequests() {
		

		List<LeaveReq> llr = lrs.getAllLeaveRequests();

		System.out.println(GREEN + "\nHere's the list of all the leave Requests :-\n" + RESET);

		System.out.println(GREEN + "+----------+------------+--------------+--------------+-----------------+--------------+" + RESET);
	    System.out.println(GREEN + "| Leave ID | EmployeeID | Start Date   | End Date     | Leave Type      | Leave Status |" + RESET);
	    System.out.println(GREEN + "+----------+------------+--------------+--------------+-----------------+--------------+" + RESET);

	    for (LeaveReq request : llr) {
	        System.out.println(GREEN + request.toString() + RESET);
	    }

	    System.out.println(GREEN + "+----------+------------+--------------+--------------+-----------------+--------------+" + RESET);
	}
	
	/**
	 * This method gets called in the handeLeaveRequestManagement() method when the user
	 * selects view your leave requests option in the leave request management menu. This method
	 * takes an input and further calls getYourLeaveRequests() from LeaveRequestService class 
	 * which returns a list.
	 */
	private static void viewYourLeaveRequests() {
			
		

		System.out.println(PURPLE + "\n--- View Your Leave Request(s) ---" + RESET);

		System.out.print(BLUE + "Enter your Employee ID: " + RESET);
		int empId = sc.nextInt();
		
		List<LeaveReq> llr = lrs.getYourLeaveRequests(empId);

		System.out.println(GREEN + "\nHere's the list of all the requested leave Requests :-\n" + RESET);

		System.out.println(GREEN + "+----------+------------+--------------+--------------+-----------------+--------------+" + RESET);
	    System.out.println(GREEN + "| Leave ID | EmployeeID | Start Date   | End Date     | Leave Type      | Leave Status |" + RESET);
	    System.out.println(GREEN + "+----------+------------+--------------+--------------+-----------------+--------------+" + RESET);

	    for (LeaveReq request : llr) {
	        System.out.println(GREEN + request.toString() + RESET);
	    }

	    System.out.println(GREEN + "+----------+------------+--------------+--------------+-----------------+--------------+" + RESET);
	}
	
	/**
	 * This method gets called in the handeLeaveRequestManagement() method when the user
	 * selects view your leave requests option in the leave request management menu. This method 
	 * takes necessary input and further calls getYourLeaveRequestsForApproval() from LeaveRequestService 
	 * class which returns a list.
	 */
	private static void viewYourLeaveRequestsForApproval() {
		

		System.out.println(PURPLE + "\n--- View Your Leave Request(s) For Approval ---" + RESET);

		System.out.print(BLUE + "Enter your Employee ID: " + RESET);
		int manId = sc.nextInt();
		
		List<LeaveReq> llr = lrs.getYourLeaveRequestsForApproval(manId);
		
		if(es.isManager(manId)){
			System.out.println(GREEN + "\nHere's the list of all the requested leave Requests :-\n" + RESET);
			
			System.out.println(GREEN + "+----------+------------+--------------+--------------+-----------------+--------------+" + RESET);
		    System.out.println(GREEN + "| Leave ID | EmployeeID | Start Date   | End Date     | Leave Type      | Leave Status |" + RESET);
		    System.out.println(GREEN + "+----------+------------+--------------+--------------+-----------------+--------------+" + RESET);
	
		    for (LeaveReq request : llr) {
		        System.out.println(GREEN + request.toString() + RESET);
		    }
	
		    System.out.println(GREEN + "+----------+------------+--------------+--------------+-----------------+--------------+" + RESET);
		}
	}

}
