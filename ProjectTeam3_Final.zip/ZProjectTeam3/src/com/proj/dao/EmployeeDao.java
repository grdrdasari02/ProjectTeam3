package com.proj.dao;

import java.util.List;

import com.proj.model.Employee;

/**
 * Contains method definitions that will be implemented in EmployeeService class.
 * @author Chakri K
 */
public interface EmployeeDao {

	void addEmployees(Employee emp);

	List<Employee> getAllEmployees();

	boolean isManager(int empId);

	boolean isCorrectPair(int manId, int empId);

}
