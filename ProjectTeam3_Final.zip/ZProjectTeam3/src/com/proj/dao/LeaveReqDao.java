package com.proj.dao;

import java.util.List;

import com.proj.model.LeaveReq;

/**
 * Contains method definitions that will be implemented in LeaveRequestService class.
 * @author Chakri K
 */
public interface LeaveReqDao {

	void addLeaveReq(LeaveReq leavereq);

	void updateLeaveStatus(int manId, int leaveId, String status);

	List<LeaveReq> getAllLeaveRequests();

	List<LeaveReq> getYourLeaveRequests(int empId);

	List<LeaveReq> getYourLeaveRequestsForApproval(int manId);

}
