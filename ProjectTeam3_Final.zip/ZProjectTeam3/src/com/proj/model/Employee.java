package com.proj.model;

/**
 * POJO class to represent an Employee. 
 * Contains getters and setters to all the members.
 * Contains the default constructor and an overloaded constructor.
 * Contains an overridden toString() method.
 * @author Vishal K
 */
public class Employee {
	
	private int eid;
	private String ename;
	private String edept;
	private boolean is_manager;
	private int mid;

	public Employee() {

	}

	public Employee(int eid, String ename, String edept, boolean is_manager, int mid) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.edept = edept;
		this.is_manager = is_manager;
		this.mid = mid;
	}

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getEdept() {
		return edept;
	}

	public void setEdept(String edept) {
		this.edept = edept;
	}

	public boolean isIs_manager() {
		return is_manager;
	}

	public void setIs_manager(boolean is_manager) {
		this.is_manager = is_manager;
	}

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

//	@Override
//	public String toString() {
//		return "Employee [eid=" + eid + ", ename=" + ename + ", edept=" + edept + ", is_manager=" + is_manager
//				+ ", mid=" + mid + "]";
//	}
	
	@Override
	public String toString() {
		return String.format(
		        "| %-5d | %-20s | %-15s | %-10s | %-10d |",
		        eid, ename, edept, (is_manager ? "Yes" : "No"), mid
		    );
	}

}
