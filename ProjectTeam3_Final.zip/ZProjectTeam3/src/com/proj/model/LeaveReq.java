package com.proj.model;

import java.util.Date;

/**
 * POJO class to represent a Leave Request. 
 * Contains getters and setters to all the members.
 * Contains the default constructor and an overloaded constructor.
 * Contains an overridden toString() method.
 * @author Vishal K
 */
public class LeaveReq {

	private int lid;
	private int emp_id;
	private Date start_date;
	private Date end_date;
	private String leave_type;
	private String leave_status;
	
	public LeaveReq() {
		
	}

	public LeaveReq(int lid, int emp_id, Date sdate, Date edate, String leave_type, String leave_status) {
		
		this.lid = lid;
		this.emp_id = emp_id;
		this.start_date = sdate;
		this.end_date = edate;
		this.leave_type = leave_type;
		this.leave_status = leave_status;
	}

	public int getLid() {
		return lid;
	}

	public void setLid(int lid) {
		this.lid = lid;
	}

	public int getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}

	public Date getStart_date() {
		return start_date;
	}

	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}

	public Date getEnd_date() {
		return end_date;
	}

	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}

	public String getLeave_type() {
		return leave_type;
	}

	public void setLeave_type(String leave_type) {
		this.leave_type = leave_type;
	}

	public String getLeave_status() {
		return leave_status;
	}

	public void setLeave_status(String leave_status) {
		this.leave_status = leave_status;
	}

//	@Override
//	public String toString() {
//		return "LeaveReq [lid=" + lid + ", emp_id=" + emp_id + ", start_date=" + start_date + ", end_date=" + end_date
//				+ ", leave_type=" + leave_type + ", leave_status=" + leave_status + "]";
//	}
	
	@Override
	public String toString() {
	    return String.format(
	        "| %-8d | %-10d | %-12s | %-12s | %-15s | %-12s |",
	        lid, emp_id, start_date, end_date, leave_type, leave_status
	    );
	}
	
	
	
	
	

	
	
}
