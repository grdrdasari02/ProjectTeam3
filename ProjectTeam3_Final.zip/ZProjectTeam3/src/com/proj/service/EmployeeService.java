package com.proj.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.proj.dao.EmployeeDao;
import com.proj.model.Employee;
import com.proj.utils.DatabaseUtil;

/**
 * This class implements the EmployeeDao interface and contains methods for adding new employees
 * and viewing all the employees.
 * @author Ankitha K
 */
public class EmployeeService implements EmployeeDao{
	
	private static final String RESET = "\033[0m";
    private static final String GREEN = "\033[0;32m";
    private static final String YELLOW = "\033[0;33m";
    private static final String BLUE = "\033[0;34m";
    private static final String PURPLE = "\033[0;35m";
    private static final String RED = "\033[0;31m";
    private static final String CYAN = "\033[0;36m";
    
    Connection con = null;
    
    public EmployeeService() {

    	try {
    		con = DatabaseUtil.getConnection();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }

	/**
	 * This method is called in addNewEmployee() method from the 
	 * LeaveManagementSystem Class (void main() class) with an employee object as parameter.
	 * The method initially checks the validity/existence of managerId of the passed employee and then
	 * proceeds to insert the employee data into the database. Duplicate Primary Key exception is  
	 * is explicitly handled.
	 * @param employee - Employee object created in the addNewEmployee() method.
	 */
	@Override
	public void addEmployees(Employee employee) {
		
		if(employee.getMid()!=0){
			String q="Select * from public.\"Employees\" where eid = ? and is_manager=true";
			
			try {
				PreparedStatement st = con.prepareStatement(q);
				st.setInt(1, employee.getMid());
				
				ResultSet rs=st.executeQuery();
				if(rs.next()) {}
				else {
					System.out.println(RED + "Manager with the given ID does not exist" + RESET);
					return;
				}
				
				
			} catch (SQLException e) {
				e.printStackTrace();
				return;
			}
		}
		
		
		String query = "Insert into public.\"Employees\"(eid,ename,edept,is_manager,mid) Values(?,?,?,?,?)";
		
		
		try {
			PreparedStatement st = con.prepareStatement(query);
			
			st.setInt(1, employee.getEid());
			st.setString(2, employee.getEname());
			st.setString(3, employee.getEdept());
			st.setBoolean(4, employee.isIs_manager());
			st.setInt(5, employee.getMid());
			st.executeUpdate();

		} catch (SQLException e) {
			 if ("23505".equals(e.getSQLState())) {
	                System.out.println(RED + "Error: Duplicate key violation. The employee ID already exists in the database." + RESET);
	                return;
	            } else {
	                e.printStackTrace();
	                System.out.println(RED + "An error occurred while adding the employee." + RESET);
	                return;
	            }
		}
		
		System.out.println(GREEN + "\nEmployee added successfully to the system." + RESET);
		
		

	}

	/**
	 * This method is called in viewAllEmployee() method from the 
	 * LeaveManagementSystem Class (void main() class). This method establishes a connection and 
	 * gets all the employee into a list and returns it.
	 * @return employees - List of all the employees.
	 */
	@Override
	public List<Employee> getAllEmployees() {
		
		List<Employee> employees=new ArrayList<Employee>();
		String query="Select * from public.\"Employees\" order by eid asc";
		
		try {
			PreparedStatement st = con.prepareStatement(query);
			ResultSet rs=st.executeQuery();
			
			while(rs.next()) {
				Employee emp=new Employee(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getBoolean(4),rs.getInt(5));
				
				employees.add(emp);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
            System.out.println(RED + "An error occurred while getting the list of employees" + RESET);
		}
		
		return employees;

}

	

	/**
	 * Method to check whether a particular employee is a manager or not through their id. Returns
	 * a boolean variable correspondingly.
	 * @param empId - Employee ID to be checked.
	 * @return boolean variable corresponding to existence of a manager.
	 */
	@Override
	public boolean isManager(int empId) {
		
		String query="Select is_manager from public.\"Employees\" where eid = ?";
		
		try {
			PreparedStatement st = con.prepareStatement(query);
			st.setInt(1, empId);
			
			ResultSet rs=st.executeQuery();
			if(rs.next()) return rs.getBoolean("is_manager");
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
			
		
		return false;
	}

	/**
	 * Method to check whether a particular employee is reporting to the given manager or not
	 * through their id. Returns a boolean variable correspondingly.
	 * @param manId - Employee ID of the supposedly manager.
	 * @param empId - ID of the employee supposedly reporting to the other employee.
	 * @return boolean variable corresponding to the valid manager-employee relation.
	 */
	@Override
	public boolean isCorrectPair(int manId, int empId) {
		
		String query="Select mid from public.\"Employees\" where eid = ?";
		
		try {
			
			
			PreparedStatement st = con.prepareStatement(query);
			st.setInt(1, empId);
			
			ResultSet rs=st.executeQuery();
			if(rs.next())  return (manId==rs.getInt(1));
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
}