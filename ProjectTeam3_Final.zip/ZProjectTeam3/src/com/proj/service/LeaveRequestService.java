package com.proj.service;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.proj.dao.LeaveReqDao;
import com.proj.model.Employee;
import com.proj.model.LeaveReq;
import com.proj.utils.DatabaseUtil;

/**
 * This class implements the LeaveReqDao interface and contains the methods that facilitates
 * adding leaving request, approving leave requests and viewing leave request.
 * @author Chakri K, Giridhar D
 */
public class LeaveRequestService implements LeaveReqDao {
	
	private static final String RESET = "\033[0m";
    private static final String GREEN = "\033[0;32m";
    private static final String YELLOW = "\033[0;33m";
    private static final String BLUE = "\033[0;34m";
    private static final String PURPLE = "\033[0;35m";
    private static final String RED = "\033[0;31m";
    private static final String CYAN = "\033[0;36m";

    private static EmployeeService es = new EmployeeService();
    
    Connection con = null;
    
    public LeaveRequestService() {
    	
    	try {
    		con = DatabaseUtil.getConnection();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * This method is called in applyForLeave() method from the 
	 * LeaveManagementSystem Class (void main() class) with an leavereq object as parameter. 
	 * The methods establishes a connection and proceeds to insert the leave request data into the 
	 * database table. Foreign Key Violation exception is explicitly handled.
	 * @param leaveReq - LeaveReq object created in the applyForLeave
	 * @author Chakri K
	 */
	@Override
	public void addLeaveReq(LeaveReq leavereq) {

		String query="Insert into public.\"Leave_Request\"( emp_id, start_date, end_date, leave_type, leave_status) values(?,?,?,?,?)";
		 
		try {
			PreparedStatement st = con.prepareStatement(query);
			st.setInt(1, leavereq.getEmp_id());
			st.setDate(2, new java.sql.Date(leavereq.getStart_date().getTime()));
			st.setDate(3, new java.sql.Date(leavereq.getEnd_date().getTime()));
			st.setString(4, leavereq.getLeave_type());
			st.setString(5, leavereq.getLeave_status());
			st.executeUpdate();
		} catch (SQLException e) {
			if ("23505".equals(e.getSQLState())) {
                System.out.println(RED + "Error: Duplicate key violation. The leave ID already exists in the database." + RESET);
                return;
            }
			else if ("23000".equals(e.getSQLState())) {
                System.out.println(RED + "Error: Foreign key constraint violation. Please ensure the employee ID exists." + RESET);
                return;
            } else {
                e.printStackTrace();
                System.out.println(RED + "An error occurred while adding the leave request." + RESET);
                return;
            }
		}

		System.out.println(GREEN + "\nYour leave request has been submitted successfully." + RESET);
		
	}

	/**
	 * This method is called in approveLeave() method from the
	 * LeaveManagementSystem Class (void main() class) with a manager id, leave id and status
	 * that should be updated to as parameters. The method initially checks the validity of leave id,
	 * manager id and then checks whether the employee corresponding to the leave request is reporting
	 * the given manager or not. Then proceeds to update the leave status in the database.
	 * @param manId - ID of the manager taken from the user.
	 * @param leaveId - ID of the leave request taken from the user
	 * @param status - Approval or rejection string given by the user.
	 * @author Giridhar D
	 */
	@Override
	public void updateLeaveStatus(int manId, int leaveId, String status) {
		
		
		String qr="Select * from public.\"Leave_Request\" where lid = ?";
		
		try {
			
			PreparedStatement st = con.prepareStatement(qr);
			st.setInt(1, leaveId);
			
			ResultSet rs=st.executeQuery();
			if(rs.next()) {}
			else {
				System.out.println(RED + "Leave Request with the given ID does not exist" + RESET);
				return;
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
			return;
		}
		
		
		if(es.isManager(manId)) {
			
			int empId=0;
			
			String q = "Select emp_id from public.\"Leave_Request\" where lid = ?";
			try {
				PreparedStatement st = con.prepareStatement(q);
				st.setInt(1, leaveId);
				ResultSet rs=st.executeQuery();
				
				while(rs.next()) empId = rs.getInt(1);
				
			} catch (SQLException e) {
				e.printStackTrace();
	            System.out.println(RED + "An error occurred while getting the list of employees" + RESET);
	            return;
			}
			
			
			if(es.isCorrectPair(manId, empId)) {
				
				String query="update public.\"Leave_Request\" set leave_status = ? where lid = ?";
				
				try {
					PreparedStatement st = con.prepareStatement(query);
					st.setString(1, status);
					st.setInt(2, leaveId);
					
					st.executeUpdate();
					
				} catch (SQLException e) {
					e.printStackTrace();
					return;
				}
			}
			else{
				System.out.println(RED + "You can't update the given leave request." + RESET);
				return;
			}
			
			
		}
		else {
			System.out.println(RED + "Invalid operation. You are not a manager." + RESET);
			return;
		}
		

		System.out.println(GREEN + "\nLeave request processed successfully." + RESET);
		
	}

	/**
	 * This method is called in viewAllLeaveRequests() method from the 
	 * LeaveManagementSystem Class (void main() class). This method establishes a connection and
	 * gets all the leave request table into a list and returns it.
	 * @return leaveRequests - the list of all the leave requests.
	 * @author Chakri K
	 */
	@Override
	public List<LeaveReq> getAllLeaveRequests() {
		
		List<LeaveReq> leaveRequests=new ArrayList<>();
		String query="Select * from public.\"Leave_Request\" order by lid asc";
		
		try {
			PreparedStatement st = con.prepareStatement(query);
			ResultSet rs=st.executeQuery();
			
			while(rs.next()) {
				LeaveReq lr = new LeaveReq(rs.getInt(1),rs.getInt(2), rs.getDate(3),rs.getDate(4),rs.getString(5),rs.getString(6));
				
				leaveRequests.add(lr);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return leaveRequests;
	}
	
	/**
	 * This method is called in viewYourLeaveRequests() method from the 
	 * LeaveManagementSystem Class (void main() class) with an employee id as parameter. 
	 * This method establishes a connection and gets all the leave requests with the given employee id
	 * into a list and returns it.
	 * @param empId - Employee ID given by the user.
	 * @return leaveRequest - the list of all the required leaveRequests.
	 */
	@Override
	public List<LeaveReq> getYourLeaveRequests(int empId) {
		
		List<LeaveReq> leaveRequests=new ArrayList<>();
		String query="Select * from public.\"Leave_Request\" where emp_id=? order by lid asc";
		
		try {
			PreparedStatement st = con.prepareStatement(query);
			st.setInt(1, empId);
			ResultSet rs=st.executeQuery();
			
			while(rs.next()) {
				LeaveReq lr = new LeaveReq(rs.getInt(1),rs.getInt(2), rs.getDate(3),rs.getDate(4),rs.getString(5),rs.getString(6));
				
				leaveRequests.add(lr);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return leaveRequests;
	}

	/**
	 * This method is called in viewYourLeaveRequestsForApproval() method from the 
	 * LeaveManagementSystem Class (void main() class) with a manager's employee id as parameter. 
	 * This method initially validates the manager id and then gets all the leave requests 
	 * of the employees reporting to the manager into a list and returns it.
	 * @param manId - Manager's employee ID given by the user.
	 * @return leaveRequest - the list of all the required leaveRequests.
	 */
	@Override
	public List<LeaveReq> getYourLeaveRequestsForApproval(int manId) {
		

		List<LeaveReq> leaveRequests=new ArrayList<>();
		if(es.isManager(manId)) {
			
			
			String query="Select * from public.\"Leave_Request\" order by lid asc";
			
			try {
				PreparedStatement st = con.prepareStatement(query);
				ResultSet rs=st.executeQuery();
				
				while(rs.next()) {
					
					
					if(es.isCorrectPair(manId, rs.getInt(2))) {
						LeaveReq lr = new LeaveReq(rs.getInt(1),rs.getInt(2), rs.getDate(3),rs.getDate(4),rs.getString(5),rs.getString(6));
						leaveRequests.add(lr);
					}
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			return leaveRequests;
		}
		else {
			System.out.println(RED + "Invalid Operation. You need to be a manager." + RESET);
			return leaveRequests;
		}
		
		
		
	}

	

}
