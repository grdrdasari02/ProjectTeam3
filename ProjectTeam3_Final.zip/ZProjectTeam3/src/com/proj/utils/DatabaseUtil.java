package com.proj.utils;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * This class contains database connectivity implementation using the properties from 
 * application.properties file.
 * @author Vishal K
 */
public class DatabaseUtil{
	
	static Properties props = null;
	static Connection con = null;
	
	static {
		try {
			FileReader reader = new FileReader( new File("C:\\Users\\localadmin\\Downloads\\ZProjectTeam3\\src\\application.properties"));
			props = new Properties();
			props.load(reader);
			Class.forName(props.getProperty("drivername"));
			
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	
	}
	
	public static Connection getConnection() throws SQLException {
		return  DriverManager.getConnection(props.getProperty("con"), props.getProperty("username"),
				props.getProperty("password"));
	
		
	}
}
